import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        Homepage runProgram = new Homepage();
        runProgram.setVisible(true);
    }
}